// This will show or hide the [Login/Logout/Write a Review/Pending Reviews/Products/Incoming Messages] buttons according to the user_token and user_type of the user.
change_buttons_behaviors();
